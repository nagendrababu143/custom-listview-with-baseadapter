package com.nbktech.listviewwithbaseadapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class MobilesAdapter extends BaseAdapter {

    Context context;
    String[] mobilenames;

    public MobilesAdapter() {
    }

    public MobilesAdapter(Context context, String[] mobilenames) {
        this.context = context;
        this.mobilenames = mobilenames;
    }

    @Override
    public int getCount() {
        return mobilenames.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View view1 = View.inflate(context,R.layout.eachitem,null);

        ImageView imageView = (ImageView)view1.findViewById(R.id.nbk_image);
        TextView textView = (TextView)view1.findViewById(R.id.nbk_name);

        Picasso.get().load(R.drawable.nbktech).into(imageView);
        textView.setText(mobilenames[i]);

        return view1;
    }
}
